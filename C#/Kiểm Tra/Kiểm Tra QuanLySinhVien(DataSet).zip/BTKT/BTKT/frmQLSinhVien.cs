﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BTKT
{
    public partial class frmQLSinhVien : Form
    {
        public frmQLSinhVien()
        {
            InitializeComponent();
        }

        private string strketnoi = @"Data Source = (local); Initial Catalog= QLSV; Integrated Security=true;";
        private List<SinhVien> LoadDSSinhVien;
        private SinhVien svchon = null;

        private void frmQLSinhVien_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'qLSVDataSet1.Sinhvien' table. You can move, or remove it, as needed.
           
            // TODO: This line of code loads data into the 'qLSVDataSet.Sinhvien' table. You can move, or remove it, as needed.
            

            dataGridView1.AutoGenerateColumns = false;
            dtbngay.Format = DateTimePickerFormat.Custom;
            dtbngay.CustomFormat = "dd-MM-yyyy";
            LoadDanhSachSinhVien();
        }

        private void LoadDanhSachSinhVien()
        {
            SqlConnection sconn = new SqlConnection(strketnoi);
            sconn.Open();
            string strtuyvan = "Select * from Sinhvien  Where TrangThai=NULL";
            SqlCommand scom = new SqlCommand(strtuyvan, sconn);
            SqlDataReader sdr = scom.ExecuteReader();
            if (LoadDSSinhVien != null)
            {
                LoadDSSinhVien.Clear();
            }

            LoadDSSinhVien = new List<SinhVien>();
            while (sdr.Read())
            {
                SinhVien sv = new SinhVien();
                sv.STT = int.Parse(sdr["STT"].ToString());
                sv.HO = sdr["HO"].ToString();
                sv.TEN = sdr["TEN"].ToString();
                sv.MASINHVIEN = int.Parse(sdr["MASINHVIEN"].ToString());
                sv.CHUYENCAN = int.Parse(sdr["CHUYENCAN"].ToString());
                sv.KTHS1A = int.Parse(sdr["KTHS1A"].ToString());
                sv.KTHS1B = int.Parse(sdr["KTHS1B"].ToString());
                sv.KTHS2A = int.Parse(sdr["KTHS2A"].ToString());
                sv.KTHS2B = int.Parse(sdr["KTHS2B"].ToString());
                sv.TBKIEMTRA = int.Parse(sdr["TBKIEMTRA"].ToString());
                sv.THILAN1 = int.Parse(sdr["THILAN1"].ToString());
                sv.TONGKET = int.Parse(sdr["TONGKET"].ToString());
                
                sv.NGAYSINH = DateTime.Parse(sdr["NGAYSINH"].ToString());
                sv.TRANGTHAI = int.Parse(sdr["TRANGTHAI"].ToString());

                LoadDSSinhVien.Add(sv);
            }
            sdr.Close();
            sconn.Close();

            dataGridView1.DataSource = LoadDSSinhVien;
        }

        private void GetDataChiTiet()
        {
            if (svchon == null)
            {
                svchon = new SinhVien();
            }
            svchon.STT = int.Parse(txtstt.Text);
            svchon.MASINHVIEN = int.Parse(txtma.Text);
            svchon.HO = txtho.Text;
            svchon.TEN = txtten.Text;
            svchon.NGAYSINH = dtbngay.Value;
            svchon.CHUYENCAN = int.Parse(txtchuyencan.Text);
            svchon.KTHS1A = int.Parse(txt1a.Text);
            svchon.KTHS1B = int.Parse(txt1b.Text);
            svchon.KTHS2A = int.Parse(txt2a.Text);
            svchon.KTHS2B = int.Parse(txt2b.Text);
            svchon.TBKIEMTRA = int.Parse(txttbkt.Text);
            svchon.THILAN1 = int.Parse(txtthi.Text);
            svchon.TONGKET = int.Parse(txttongket.Text);    
        }

        private void BindingChiTietSinhVien()
        {
            if (svchon != null)
            {
                txtstt.Text = svchon.STT.ToString();
                txtma.Text = svchon.MASINHVIEN.ToString();
                txtho.Text = svchon.HO;
                txtten.Text = svchon.TEN;
                dtbngay.Value = svchon.NGAYSINH;

                txtchuyencan.Text = svchon.CHUYENCAN.ToString();
                txt1a.Text = svchon.KTHS1A.ToString();
                txt1b.Text = svchon.KTHS1B.ToString();
                txt2a.Text = svchon.KTHS2A.ToString();
                txt2b.Text = svchon.KTHS2B.ToString();
                txttbkt.Text = svchon.TBKIEMTRA.ToString();
                txtthi.Text = svchon.THILAN1.ToString();
                txttongket.Text = svchon.TONGKET.ToString();            
            }

            else
            {
                txtstt.Text = string.Empty;
                txtma.Text = string.Empty;
                txtten.Text = string.Empty;
                txtho.Text = string.Empty;
                dtbngay.Value = DateTime.Now;
                txtchuyencan.Text = string.Empty;
                txt1a.Text = string.Empty;
                txt1b.Text = string.Empty;
                txt2a.Text = string.Empty;
                txt2b.Text = string.Empty;
                txttbkt.Text = string.Empty;
                txtthi.Text = string.Empty;
                txttongket.Text = string.Empty;
            }
        }

      

        private void btnthem_Click(object sender, EventArgs e)
        {

            if (svchon == null)
            {
                GetDataChiTiet();
                string strlenhthucthi = "Insert Into Sinhvien(STT,MASINHVIEN, HO, TEN, NGAYSINH, CHUYENCAN, KTHS1A,KTHS1B,KTHS2A,KTHS2B,TBKIEMTRA,THILAN1,TONGKET,TRANGTHAI)Values(@STT,@MASINHVIEN, @HO, @TEN, @NGAYSINH, @CHUYENCAN,@KTHS1A,,@KTHS1B,,@KTHS2A,,@KTHS2B,@TBKIEMTRA,@THILAN1,@TONGKET,1)";
                SqlConnection sconn = new SqlConnection(strketnoi);
                sconn.Open();
                SqlCommand scom = new SqlCommand(strlenhthucthi, sconn);
                scom.Parameters.AddWithValue("@STT", svchon.STT);
                scom.Parameters.AddWithValue("@MASINHVIEN", svchon.MASINHVIEN);
                scom.Parameters.AddWithValue("@Ho", svchon.HO);
                scom.Parameters.AddWithValue("@Ten", svchon.TEN);
                scom.Parameters.AddWithValue("@Ngaysinh", svchon.NGAYSINH);
                scom.Parameters.AddWithValue("@CHUYENCAN", svchon.CHUYENCAN);
                scom.Parameters.AddWithValue("@KTHS1A", svchon.KTHS1A);
                scom.Parameters.AddWithValue("@KTHS1B", svchon.KTHS1B);
                scom.Parameters.AddWithValue("@KTHS2A", svchon.KTHS2A);
                scom.Parameters.AddWithValue("@KTHS2B", svchon.KTHS2B);
                scom.Parameters.AddWithValue("@TBKIEMTRA", svchon.TBKIEMTRA);
                scom.Parameters.AddWithValue("@THILAN1", svchon.THILAN1);
                scom.Parameters.AddWithValue("@TONGKET", svchon.TONGKET);

                int iketqua = scom.ExecuteNonQuery();
                sconn.Close();
                if (iketqua > 0)
                {
                    MessageBox.Show("Luu moi thanh cong");
                    LoadDanhSachSinhVien();
                }

                else
                {
                    MessageBox.Show("Luu khong thanh cong");
                    svchon = null;
                }
            }
        }

        private void dataGridView1_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                svchon = (SinhVien)dataGridView1.SelectedRows[0].DataBoundItem;

            }
            else
            {
                svchon = null;

            }
            BindingChiTietSinhVien();
        }

        private void sinhvienBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                svchon = (SinhVien)dataGridView1.SelectedRows[0].DataBoundItem;

            }
            else
            {
                svchon = null;

            }
            BindingChiTietSinhVien();
        }


    }
}
