﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaiKT
{
    class QLNhatro
    {
        public int nhatro { get; set; }
        public string loaihinh { get; set; }
        public int dientich { get; set; }
        public int giaphong { get; set; }
        public string diachi { get; set; }
        public string quan { get; set; }
        public string mota { get; set; }
        public int trangthai { get; set; }
    }
}
