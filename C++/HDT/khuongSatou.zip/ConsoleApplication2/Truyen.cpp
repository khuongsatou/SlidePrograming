#include "Truyen.h"


Truyen::Truyen()
{
}


Truyen::~Truyen()
{
}
