#pragma once
class Truyen :
	public Sach
{
public:
	Truyen();
	~Truyen();
};

