#include "SGK.h"


SGK::SGK()
{
}


SGK::~SGK()
{
}
