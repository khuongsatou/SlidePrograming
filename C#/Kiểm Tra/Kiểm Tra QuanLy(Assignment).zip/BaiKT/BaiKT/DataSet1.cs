﻿namespace BaiKT {
    
    
    public partial class DataSet1 {
        partial class SinhVienDataTable
        {
        }
    }
}
