﻿namespace BTKT
{
    partial class frmQLSinhVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtma = new System.Windows.Forms.TextBox();
            this.txtho = new System.Windows.Forms.TextBox();
            this.txtten = new System.Windows.Forms.TextBox();
            this.txtchuyencan = new System.Windows.Forms.TextBox();
            this.txt1a = new System.Windows.Forms.TextBox();
            this.txt1b = new System.Windows.Forms.TextBox();
            this.txt2a = new System.Windows.Forms.TextBox();
            this.txt2b = new System.Windows.Forms.TextBox();
            this.txttbkt = new System.Windows.Forms.TextBox();
            this.txtthi = new System.Windows.Forms.TextBox();
            this.txttongket = new System.Windows.Forms.TextBox();
            this.dtbngay = new System.Windows.Forms.DateTimePicker();
            this.btnthem = new System.Windows.Forms.Button();
            this.btnsua = new System.Windows.Forms.Button();
            this.btnxoa = new System.Windows.Forms.Button();
            this.txtstt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.sinhvienBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.sinhvienBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã Sinh Viên:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Họ:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 159);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tên:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 209);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Ngày Sinh:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(289, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Chuyên Cần:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(291, 77);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "KTHS1A";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(291, 119);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "KTHS1B";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(291, 163);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "KTHS2A";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(291, 213);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "KTHS2B";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(549, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "TBKiemTra";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(557, 77);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Thi Lần 1";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(558, 118);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 13);
            this.label12.TabIndex = 11;
            this.label12.Text = "Tổng Kết";
            // 
            // txtma
            // 
            this.txtma.Location = new System.Drawing.Point(98, 70);
            this.txtma.Name = "txtma";
            this.txtma.Size = new System.Drawing.Size(145, 20);
            this.txtma.TabIndex = 12;
            // 
            // txtho
            // 
            this.txtho.Location = new System.Drawing.Point(98, 115);
            this.txtho.Name = "txtho";
            this.txtho.Size = new System.Drawing.Size(145, 20);
            this.txtho.TabIndex = 13;
            // 
            // txtten
            // 
            this.txtten.Location = new System.Drawing.Point(98, 156);
            this.txtten.Name = "txtten";
            this.txtten.Size = new System.Drawing.Size(145, 20);
            this.txtten.TabIndex = 14;
            // 
            // txtchuyencan
            // 
            this.txtchuyencan.Location = new System.Drawing.Point(363, 29);
            this.txtchuyencan.Name = "txtchuyencan";
            this.txtchuyencan.Size = new System.Drawing.Size(145, 20);
            this.txtchuyencan.TabIndex = 15;
            // 
            // txt1a
            // 
            this.txt1a.Location = new System.Drawing.Point(363, 74);
            this.txt1a.Name = "txt1a";
            this.txt1a.Size = new System.Drawing.Size(145, 20);
            this.txt1a.TabIndex = 16;
            // 
            // txt1b
            // 
            this.txt1b.Location = new System.Drawing.Point(363, 119);
            this.txt1b.Name = "txt1b";
            this.txt1b.Size = new System.Drawing.Size(145, 20);
            this.txt1b.TabIndex = 17;
            // 
            // txt2a
            // 
            this.txt2a.Location = new System.Drawing.Point(363, 160);
            this.txt2a.Name = "txt2a";
            this.txt2a.Size = new System.Drawing.Size(145, 20);
            this.txt2a.TabIndex = 18;
            // 
            // txt2b
            // 
            this.txt2b.Location = new System.Drawing.Point(363, 210);
            this.txt2b.Name = "txt2b";
            this.txt2b.Size = new System.Drawing.Size(145, 20);
            this.txt2b.TabIndex = 19;
            // 
            // txttbkt
            // 
            this.txttbkt.Location = new System.Drawing.Point(627, 29);
            this.txttbkt.Name = "txttbkt";
            this.txttbkt.Size = new System.Drawing.Size(145, 20);
            this.txttbkt.TabIndex = 20;
            // 
            // txtthi
            // 
            this.txtthi.Location = new System.Drawing.Point(627, 74);
            this.txtthi.Name = "txtthi";
            this.txtthi.Size = new System.Drawing.Size(145, 20);
            this.txtthi.TabIndex = 21;
            // 
            // txttongket
            // 
            this.txttongket.Location = new System.Drawing.Point(627, 115);
            this.txttongket.Name = "txttongket";
            this.txttongket.Size = new System.Drawing.Size(145, 20);
            this.txttongket.TabIndex = 22;
            // 
            // dtbngay
            // 
            this.dtbngay.CustomFormat = "dd-MM-yyyy";
            this.dtbngay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtbngay.Location = new System.Drawing.Point(98, 202);
            this.dtbngay.Name = "dtbngay";
            this.dtbngay.Size = new System.Drawing.Size(145, 20);
            this.dtbngay.TabIndex = 23;
            // 
            // btnthem
            // 
            this.btnthem.Location = new System.Drawing.Point(561, 168);
            this.btnthem.Name = "btnthem";
            this.btnthem.Size = new System.Drawing.Size(199, 23);
            this.btnthem.TabIndex = 25;
            this.btnthem.Text = "&Thêm";
            this.btnthem.UseVisualStyleBackColor = true;
            this.btnthem.Click += new System.EventHandler(this.btnthem_Click);
            // 
            // btnsua
            // 
            this.btnsua.Location = new System.Drawing.Point(561, 218);
            this.btnsua.Name = "btnsua";
            this.btnsua.Size = new System.Drawing.Size(83, 23);
            this.btnsua.TabIndex = 26;
            this.btnsua.Text = "S&ửa";
            this.btnsua.UseVisualStyleBackColor = true;
            // 
            // btnxoa
            // 
            this.btnxoa.Location = new System.Drawing.Point(674, 218);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(86, 23);
            this.btnxoa.TabIndex = 27;
            this.btnxoa.Text = "X&óa";
            this.btnxoa.UseVisualStyleBackColor = true;
            // 
            // txtstt
            // 
            this.txtstt.Location = new System.Drawing.Point(98, 29);
            this.txtstt.Name = "txtstt";
            this.txtstt.Size = new System.Drawing.Size(145, 20);
            this.txtstt.TabIndex = 29;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 13);
            this.label13.TabIndex = 28;
            this.label13.Text = "STT:";
            // 
            // sinhvienBindingSource
            // 
            this.sinhvienBindingSource.DataMember = "Sinhvien";
            this.sinhvienBindingSource.CurrentChanged += new System.EventHandler(this.sinhvienBindingSource_CurrentChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(38, 275);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(774, 150);
            this.dataGridView1.TabIndex = 30;
            // 
            // frmQLSinhVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 538);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtstt);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.btnxoa);
            this.Controls.Add(this.btnsua);
            this.Controls.Add(this.btnthem);
            this.Controls.Add(this.dtbngay);
            this.Controls.Add(this.txttongket);
            this.Controls.Add(this.txtthi);
            this.Controls.Add(this.txttbkt);
            this.Controls.Add(this.txt2b);
            this.Controls.Add(this.txt2a);
            this.Controls.Add(this.txt1b);
            this.Controls.Add(this.txt1a);
            this.Controls.Add(this.txtchuyencan);
            this.Controls.Add(this.txtten);
            this.Controls.Add(this.txtho);
            this.Controls.Add(this.txtma);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmQLSinhVien";
            this.Text = "frmQLSinhVien";
            this.Load += new System.EventHandler(this.frmQLSinhVien_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sinhvienBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtma;
        private System.Windows.Forms.TextBox txtho;
        private System.Windows.Forms.TextBox txtten;
        private System.Windows.Forms.TextBox txtchuyencan;
        private System.Windows.Forms.TextBox txt1a;
        private System.Windows.Forms.TextBox txt1b;
        private System.Windows.Forms.TextBox txt2a;
        private System.Windows.Forms.TextBox txt2b;
        private System.Windows.Forms.TextBox txttbkt;
        private System.Windows.Forms.TextBox txtthi;
        private System.Windows.Forms.TextBox txttongket;
        private System.Windows.Forms.DateTimePicker dtbngay;
        private System.Windows.Forms.Button btnthem;
        private System.Windows.Forms.Button btnsua;
        private System.Windows.Forms.Button btnxoa;
        private System.Windows.Forms.TextBox txtstt;
        private System.Windows.Forms.Label label13;

        private System.Windows.Forms.BindingSource sinhvienBindingSource;
        private System.Windows.Forms.DataGridView dataGridView1;
       
    }
}