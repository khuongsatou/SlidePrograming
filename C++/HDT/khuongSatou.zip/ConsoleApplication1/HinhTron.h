#pragma once
#include"HinhElip.h"

class HinhTron: public HinhElip {
public:
	HinhTron();
	~HinhTron();

	virtual void Nhap();
	virtual void Xuat();
};

