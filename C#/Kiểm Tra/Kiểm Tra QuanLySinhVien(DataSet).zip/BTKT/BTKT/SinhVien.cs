﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTKT
{
    class SinhVien
    {
        public int STT { get; set; }
        public int MASINHVIEN { get; set; }
        public string HO { get; set; }
        public string TEN { get; set; }
        public DateTime NGAYSINH { get; set; }
        public int CHUYENCAN { get; set; }
        public int KTHS1A { get; set; }
        public int KTHS1B { get; set; }
        public int KTHS2A { get; set; }
        public int KTHS2B { get; set; }
        public int TBKIEMTRA { get; set; }
        public int THILAN1 { get; set; }
        public int TONGKET { get; set; }
        public int TRANGTHAI { get; set; }
    }
}
