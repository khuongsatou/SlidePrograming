#include "HinhHoc.h"

HinhHoc::HinhHoc() {
}

HinhHoc::~HinhHoc() {
}
