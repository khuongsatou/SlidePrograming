﻿namespace RapChieuPhim_PhatSinhDong
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.flpGhe = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtTongTien = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lstGheDaChon = new System.Windows.Forms.ListBox();
            this.btnThongKe = new System.Windows.Forms.Button();
            this.btnXoaGheDaChon = new System.Windows.Forms.Button();
            this.btnXemMoi = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtThanhTien = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lstGheDangChon = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Chức năng";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Blue;
            this.panel1.Controls.Add(this.label1);
            this.panel1.ForeColor = System.Drawing.Color.Aqua;
            this.panel1.Location = new System.Drawing.Point(1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(723, 22);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(1, 13);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(720, 43);
            this.panel2.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(269, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Bán Vé Rạp Chiếu Bóng";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Red;
            this.panel3.Location = new System.Drawing.Point(0, 33);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(720, 10);
            this.panel3.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label3);
            this.panel4.Location = new System.Drawing.Point(144, 63);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(362, 34);
            this.panel4.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(149, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Màn ảnh";
            // 
            // flpGhe
            // 
            this.flpGhe.Location = new System.Drawing.Point(49, 100);
            this.flpGhe.Name = "flpGhe";
            this.flpGhe.Size = new System.Drawing.Size(581, 124);
            this.flpGhe.TabIndex = 4;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtTongTien);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lstGheDaChon);
            this.groupBox1.Location = new System.Drawing.Point(7, 230);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(265, 260);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Các Ghế Đã Chọn";
            // 
            // txtTongTien
            // 
            this.txtTongTien.Location = new System.Drawing.Point(95, 226);
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.Size = new System.Drawing.Size(154, 20);
            this.txtTongTien.TabIndex = 2;
            this.txtTongTien.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 225);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Tổng Tiền(Ngàn):";
            // 
            // lstGheDaChon
            // 
            this.lstGheDaChon.FormattingEnabled = true;
            this.lstGheDaChon.Location = new System.Drawing.Point(0, 19);
            this.lstGheDaChon.Name = "lstGheDaChon";
            this.lstGheDaChon.Size = new System.Drawing.Size(249, 199);
            this.lstGheDaChon.TabIndex = 0;
            this.lstGheDaChon.SelectedIndexChanged += new System.EventHandler(this.lstGheDaChon_SelectedIndexChanged);
            // 
            // btnThongKe
            // 
            this.btnThongKe.Location = new System.Drawing.Point(296, 249);
            this.btnThongKe.Name = "btnThongKe";
            this.btnThongKe.Size = new System.Drawing.Size(138, 31);
            this.btnThongKe.TabIndex = 6;
            this.btnThongKe.Text = "Thống kê";
            this.btnThongKe.UseVisualStyleBackColor = true;
            this.btnThongKe.Click += new System.EventHandler(this.btnThongKe_Click);
            // 
            // btnXoaGheDaChon
            // 
            this.btnXoaGheDaChon.Location = new System.Drawing.Point(296, 286);
            this.btnXoaGheDaChon.Name = "btnXoaGheDaChon";
            this.btnXoaGheDaChon.Size = new System.Drawing.Size(138, 31);
            this.btnXoaGheDaChon.TabIndex = 7;
            this.btnXoaGheDaChon.Text = "<<Xóa ghế đã Chọn";
            this.btnXoaGheDaChon.UseVisualStyleBackColor = true;
            this.btnXoaGheDaChon.Click += new System.EventHandler(this.btnXoaGheDaChon_Click);
            // 
            // btnXemMoi
            // 
            this.btnXemMoi.Location = new System.Drawing.Point(296, 323);
            this.btnXemMoi.Name = "btnXemMoi";
            this.btnXemMoi.Size = new System.Drawing.Size(138, 31);
            this.btnXemMoi.TabIndex = 8;
            this.btnXemMoi.Text = "Xem Mới";
            this.btnXemMoi.UseVisualStyleBackColor = true;
            this.btnXemMoi.Click += new System.EventHandler(this.btnXemMoi_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtThanhTien);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.lstGheDangChon);
            this.groupBox2.Location = new System.Drawing.Point(450, 230);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(265, 252);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Các Ghế  Đang Chọn";
            // 
            // txtThanhTien
            // 
            this.txtThanhTien.Location = new System.Drawing.Point(110, 225);
            this.txtThanhTien.Name = "txtThanhTien";
            this.txtThanhTien.Size = new System.Drawing.Size(149, 20);
            this.txtThanhTien.TabIndex = 4;
            this.txtThanhTien.Text = "120000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 226);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Thành Tiền(Ngàn):";
            // 
            // lstGheDangChon
            // 
            this.lstGheDangChon.FormattingEnabled = true;
            this.lstGheDangChon.Location = new System.Drawing.Point(10, 19);
            this.lstGheDangChon.Name = "lstGheDangChon";
            this.lstGheDangChon.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstGheDangChon.Size = new System.Drawing.Size(249, 199);
            this.lstGheDangChon.TabIndex = 0;
            this.lstGheDangChon.SelectedIndexChanged += new System.EventHandler(this.lstGheChon_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(722, 502);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnXemMoi);
            this.Controls.Add(this.btnXoaGheDaChon);
            this.Controls.Add(this.btnThongKe);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.flpGhe);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.FlowLayoutPanel flpGhe;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtTongTien;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox lstGheDaChon;
        private System.Windows.Forms.Button btnThongKe;
        private System.Windows.Forms.Button btnXoaGheDaChon;
        private System.Windows.Forms.Button btnXemMoi;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtThanhTien;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox lstGheDangChon;
    }
}

