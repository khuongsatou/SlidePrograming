#include "Sach.h"
Sach::Sach()
{
}


Sach::~Sach()
{
}
