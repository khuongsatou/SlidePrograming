var game= function() {
	this.canvas=document.createElement("canvas");
	this.height=500;
	this.width=500;
	var luu=function () {
		document.body.appendChild(this.canvas);
	}
	
}