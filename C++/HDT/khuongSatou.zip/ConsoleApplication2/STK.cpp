#include "STK.h"


STK::STK()
{
}


STK::~STK()
{
}
